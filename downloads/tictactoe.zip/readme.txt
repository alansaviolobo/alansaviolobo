hi there,

thanks for downloading my game "tic tac toe".
this is the same game of "tic tac toe" or "X and O"

the only difference is that you dont need another player ?!
you can play with the comp !
and you can switch between EASY and TOUGH mode as well !!!

have fun and feel free to send me your comments and suggestions

alan lobo
alansaviolobo@yahoo.co.in
