hello there,

thanks for downloading my game "kaun Banega Crorepati" in other words 
"who wants to be a millionaire".

this is a quiz game which you can play with your friends.
you just have to key in one of the characters within brackets to proceed .

feel free to send in your feedback or queries at alansaviolobo@yahoo.co.in


you may not find the questions i have written in the question banks very interesting 
after some time of play.
therefore i have included two more programs namely "qadd" and "qcheck".
using these programs you can modify the questions/add more questions/write your own questions.

the procedure:

run the program qadd.pas and follow the instructions given.

if you want to change the names of the question banks then you will have to make 
the corrsp change in kbc5.pas in "procedure control" and in "procedure initialize"

you can add as many questions to the bank as you want.

* you can check your questions using qcheck.pas you can also make any minor changes 
while checking the questions.

it is important to know the file structure first:
there are 3 files involved.
namely
"easy.dat" :used for first 5 questions: easy level questions
"med.dat" :used for questions 6-10 : medium difficulty questions
"tough.dat":used for questions 11..15 :tough questions.

the questions are chosen randomly from the bank corresponding to the question number.
care is also taken to see that a question repeated in any particular game.

have fun!

alan lobo
alansaviolobo@yahoo.co.in