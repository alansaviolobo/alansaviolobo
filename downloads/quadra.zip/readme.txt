***********************QUADRA COMBAT*********************

IMPORTANT :


Make sure that the .bgi files supplied are in the same folder as the 
location of the .exe file .Or if you know what you are doing change 
the path in initgraph.

If you have any queries I'll be happy to answer to them. 
Email:	pro_kamath@rediffmail.com ( Preferred )
	pro_kamath@indiatimes.com
      	