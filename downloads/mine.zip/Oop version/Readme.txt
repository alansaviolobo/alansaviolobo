Hi there,

thanks for showing interest in my game.
right now it is not complete and i would definitely appreciate
your comments toward its improvement.

also i have noticed some errenous behaviour in the graphic 
routines of graphics.h
so you will have to bear up with that.

i welcome any suggestions towards achieving flicker free graphics

thanks

alan lobo
alansaviolobo@yahoo.co.in